Img =>
https://drive.google.com/drive/folders/1fT9VvLYIixWO4oLmto1Y_EIaHUOOB6aL
---------------------------
App:
.exe
---------------------------
Hi Guys, i'm going to teach you how to make a phone website!